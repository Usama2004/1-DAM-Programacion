package com.mycompany.eamen01;

/**
 *
 * @author oussama
 */
public class Eamen01 {

    public static void main(String[] args) {
        
        byte numero0=7;
        System.out.println("Este es el número "+numero0);
        short numero1=8;
        System.out.println("Este es el número "+numero1);
        int numero2=47;
        System.out.println("Este es el número "+numero2);
        long numero3=345667;
        System.out.println("Este es el número "+numero3);
        float numero4=4.5f;
        System.out.println("Este es el número "+numero4);
        double numero5=5.5;
        System.out.println("Este es el número "+numero5);
        char caracter='z';
        System.out.println("Este es la letra "+caracter);
        String palabra="Oussama";
        System.out.println("Mi nombre es "+palabra);
        
        
    }
}
