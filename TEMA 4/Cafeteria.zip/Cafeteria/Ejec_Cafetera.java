package ejec_cafetera;
import Package_Cafeteria.Cafeteria;


/**
 *
 * @author Oussama <oedd308@g.educaand.es>
 */
public class Ejec_Cafetera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Cafeteria c1 = new Cafeteria(1000, 800);
        Cafeteria c2 = new Cafeteria(1000);
        Cafeteria c3 = new Cafeteria();
               
    }

}
